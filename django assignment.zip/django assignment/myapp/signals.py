from django.db import transaction
from django.dispatch import Signal, receiver
from myapp.models import MyModel  # type: ignore # Example model

# Define a custom signal
my_signal = Signal()

# A signal handler that saves data
@receiver(my_signal)
def my_handler(sender, **kwargs):
    MyModel.objects.create(name="Signal Data")

# Simulating to send the signal within a transaction
try:
    with transaction.atomic():
        print("Transaction started")
        my_signal.send(sender=None)
        raise Exception("Force rollback")
except Exception:
    print("Transaction rolled back")

# Check if the data was saved
print("Is data saved:", MyModel.objects.filter(name="Signal Data").exists())
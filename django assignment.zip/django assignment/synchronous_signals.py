import time
from django.dispatch import Signal, receiver

# Define a custom signal
my_signal = Signal()

# A signal handler
@receiver(my_signal)
def my_handler(sender, **kwargs):
    print("Signal handler started")
    time.sleep(5)  # Simulate a delay to demonstrate synchronous behavior
    print("Signal handler finished")

# Simulate sending the signal
print("Sending signal")
my_signal.send(sender=None)
print("Signal sent")

import threading
from django.dispatch import Signal, receiver

# Define a custom signal
my_signal = Signal()

# A signal handler
@receiver(my_signal)
def my_handler(sender, **kwargs):
    print(f"Signal handler thread: {threading.current_thread().name}")

# Simulating to send the signal
print(f"Caller thread: {threading.current_thread().name}")
my_signal.send(sender=None)

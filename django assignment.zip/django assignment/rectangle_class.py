class Rectangle:
    def __init__(self, length: int, width: int):
        self.length = length
        self.width = width

    # Make sure the object iterable
    def __iter__(self):
        yield {'length': self.length}
        yield {'width': self.width}

# Test the Rectangle class
rect = Rectangle(10, 5)

# Iterating over the rectangle instance
for dimension in rect:
    print(dimension)
